Installation sur Chrome

Dézippez chrome-extension.zip
Dans Chrome, tapez dans la barre d'adresses :  chrome://extensions
Activez le Mode développeur (interrupteur en haut à droite)
Cliquez sur "Charger l'extension non empaquetée"
Sélectionnez le dossier dézippé