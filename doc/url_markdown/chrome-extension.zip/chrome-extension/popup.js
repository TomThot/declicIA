// ============================================================
// popup.js — Extension Chrome "URL to Markdown" (Manifest V3)
// ============================================================
// Différence principale avec la version Firefox :
//   - On utilise l'API "chrome.*" au lieu de "browser.*"
//   - On utilise chrome.scripting.executeScript() (MV3)
//     au lieu de browser.tabs.executeScript() (MV2)
//   - La fonction à exécuter dans la page est passée comme
//     référence de fonction (func:) et non comme string (code:)
// ============================================================

// --- Références aux éléments du DOM ---
const urlDisplay  = document.getElementById("url-display");
const btnConvert  = document.getElementById("btn-convert");
const statusEl    = document.getElementById("status");
const outputEl    = document.getElementById("output");
const btnCopy     = document.getElementById("btn-copy");
const btnDownload = document.getElementById("btn-download");

// --- État global ---
let currentMeta = { url: "", title: "", author: "", date: "" };

// ============================================================
// 1. AU CHARGEMENT : afficher l'URL de l'onglet actif
// ============================================================
chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
  const tab = tabs[0];
  urlDisplay.textContent = (tab && tab.url) ? tab.url : "Impossible de lire l'URL.";
});

// ============================================================
// 2. CLIC SUR "CONVERTIR"
// ============================================================
btnConvert.addEventListener("click", async () => {
  btnConvert.disabled  = true;
  btnCopy.disabled     = true;
  btnDownload.disabled = true;
  setStatus("Extraction du contenu…", "");
  outputEl.value = "";

  try {
    // Récupérer l'onglet actif
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // -------------------------------------------------------
    // chrome.scripting.executeScript (Manifest V3)
    // On passe une vraie fonction JS (func:) plutôt qu'une
    // string de code. Elle s'exécute dans le contexte de la
    // page et son return devient le résultat de l'injection.
    // -------------------------------------------------------
    const injectionResults = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPageData          // ← fonction définie plus bas
    });

    // injectionResults[0].result = valeur retournée par la fonction
    const { html: rawHTML, title, author } = injectionResults[0].result;

    if (!rawHTML) throw new Error("Impossible de récupérer le contenu de la page.");

    // Date de capture
    const date = new Date().toISOString().split("T")[0];

    // Stocker les métadonnées
    currentMeta = { url: tab.url, title, author, date };

    // Construire l'entête YAML + le corps Markdown
    setStatus("Conversion en Markdown…", "");
    const header       = buildHeader(currentMeta);
    const body         = htmlToMarkdown(rawHTML, tab.url);
    const fullMarkdown = header + "\n" + body;

    outputEl.value       = fullMarkdown;
    btnCopy.disabled     = false;
    btnDownload.disabled = false;
    setStatus(`✓ Conversion terminée (${fullMarkdown.length} caractères)`, "success");

  } catch (err) {
    setStatus("Erreur : " + err.message, "error");
    console.error("[URL→MD]", err);
  } finally {
    btnConvert.disabled = false;
  }
});

// ============================================================
// 3. FONCTION INJECTÉE DANS LA PAGE
// Cette fonction s'exécute dans le contexte de la page web,
// pas dans le popup. Elle ne peut donc pas accéder aux
// variables du popup. Elle retourne un objet sérialisable.
// ============================================================
function extractPageData() {

  // Tentative de récupération de l'auteur depuis plusieurs sources
  function getAuthor() {
    // 1. <meta name="author">
    const metaAuthor = document.querySelector('meta[name="author"]');
    if (metaAuthor?.content) return metaAuthor.content;

    // 2. Open Graph article:author
    const ogAuthor = document.querySelector('meta[property="article:author"]');
    if (ogAuthor?.content) return ogAuthor.content;

    // 3. JSON-LD (WordPress, Medium, blogs structurés…)
    const jsonLd = document.querySelector('script[type="application/ld+json"]');
    if (jsonLd) {
      try {
        const data = JSON.parse(jsonLd.textContent);
        if (data.author) {
          if (typeof data.author === "string") return data.author;
          if (data.author.name) return data.author.name;
          if (Array.isArray(data.author) && data.author[0]?.name) return data.author[0].name;
        }
      } catch(e) {}
    }

    // 4. Sélecteurs HTML sémantiques courants
    const byline = document.querySelector(
      '[rel="author"], .author, .byline, [itemprop="author"], .post-author, .entry-author'
    );
    if (byline?.textContent.trim()) return byline.textContent.trim();

    return ""; // auteur introuvable
  }

  return {
    html:   document.body.innerHTML,
    title:  document.title || "",
    author: getAuthor()
  };
}

// ============================================================
// 4. CLIC SUR "COPIER"
// ============================================================
btnCopy.addEventListener("click", () => {
  if (!outputEl.value) return;
  outputEl.select();
  document.execCommand("copy");
  setStatus("✓ Copié dans le presse-papier !", "success");
  setTimeout(() => setStatus("", ""), 2000);
});

// ============================================================
// 5. CLIC SUR "TÉLÉCHARGER"
// Crée un Blob .md et déclenche le téléchargement via une URL objet.
// ============================================================
btnDownload.addEventListener("click", () => {
  const text = outputEl.value;
  if (!text) return;

  const blob    = new Blob([text], { type: "text/markdown;charset=utf-8" });
  const blobUrl = URL.createObjectURL(blob);

  // Nom de fichier propre construit depuis le titre + la date
  const safeName = (currentMeta.title || "page")
    .replace(/[^a-zA-Z0-9À-ÿ\s\-_]/g, "")
    .replace(/\s+/g, "-")
    .toLowerCase()
    .substring(0, 60);

  const filename = safeName + "-" + currentMeta.date + ".md";

  const a = document.createElement("a");
  a.href     = blobUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(blobUrl);

  setStatus("✓ Téléchargement lancé : " + filename, "success");
  setTimeout(() => setStatus("", ""), 3000);
});

// ============================================================
// 6. ENTÊTE YAML (front matter)
// ============================================================
function buildHeader(meta) {
  return [
    "---",
    `title: "${(meta.title || meta.url).replace(/"/g, "'")}"`,
    `url: "${meta.url}"`,
    `author: "${meta.author || "Inconnu"}"`,
    `date: "${meta.date}"`,
    "---",
    ""
  ].join("\n");
}

// ============================================================
// 7. UTILITAIRE : statut
// ============================================================
function setStatus(message, type) {
  statusEl.textContent = message;
  statusEl.className   = type || "";
}

// ============================================================
// 8. CONVERTISSEUR HTML → MARKDOWN
// ============================================================
function htmlToMarkdown(html, baseUrl) {
  const parser = new DOMParser();
  const doc    = parser.parseFromString(html, "text/html");

  ["script","style","noscript","iframe","nav","footer","aside",
   "form","button","input","select","svg","canvas","video","audio"]
    .forEach(tag => doc.querySelectorAll(tag).forEach(el => el.remove()));

  const main = doc.querySelector("main, article, [role='main'], #content, .content, .post-content");
  const root = main || doc.body;

  return nodeToMarkdown(root, { baseUrl })
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// ============================================================
// 9. CONVERSION RÉCURSIVE NŒUD DOM → MARKDOWN
// ============================================================
function nodeToMarkdown(node, context) {
  const lines = [];

  for (const child of node.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) {
      const text = child.textContent.replace(/\s+/g, " ").trim();
      if (text) lines.push(text);
      continue;
    }
    if (child.nodeType !== Node.ELEMENT_NODE) continue;

    const tag      = child.tagName.toLowerCase();
    const children = () => nodeToMarkdown(child, context);
    const inline   = () => inlineText(child);

    switch (tag) {
      case "h1": lines.push("\n# "      + inline() + "\n"); break;
      case "h2": lines.push("\n## "     + inline() + "\n"); break;
      case "h3": lines.push("\n### "    + inline() + "\n"); break;
      case "h4": lines.push("\n#### "   + inline() + "\n"); break;
      case "h5": lines.push("\n##### "  + inline() + "\n"); break;
      case "h6": lines.push("\n###### " + inline() + "\n"); break;
      case "p":  lines.push("\n" + inline() + "\n");        break;
      case "hr": lines.push("\n---\n");                     break;
      case "br": lines.push("  ");                          break;

      case "a": {
        const href = child.getAttribute("href");
        const text = inline();
        if (!text) break;
        lines.push(href ? "[" + text + "](" + resolveUrl(href, context.baseUrl) + ")" : text);
        break;
      }
      case "img": {
        const src = child.getAttribute("src") || "";
        const alt = child.getAttribute("alt") || "image";
        if (src) lines.push("![" + alt + "](" + resolveUrl(src, context.baseUrl) + ")");
        break;
      }

      case "strong": case "b":   lines.push("**" + inline() + "**"); break;
      case "em":     case "i":   lines.push("_"  + inline() + "_");  break;
      case "s": case "strike":
      case "del":                lines.push("~~" + inline() + "~~"); break;

      case "code":
        lines.push(child.parentElement?.tagName.toLowerCase() === "pre"
          ? child.textContent
          : "`" + child.textContent + "`");
        break;

      case "pre": {
        const codeEl    = child.querySelector("code");
        const classStr  = (codeEl || child).className || "";
        const lang      = (classStr.match(/language-(\w+)/) || [,""])[1];
        const codeText  = (codeEl || child).textContent;
        lines.push("\n```" + lang + "\n" + codeText.trim() + "\n```\n");
        break;
      }

      case "blockquote": {
        const inner = children().join("\n");
        lines.push("\n" + inner.trim().split("\n").map(l => "> " + l).join("\n") + "\n");
        break;
      }

      case "ul":
        for (const li of child.children)
          if (li.tagName.toLowerCase() === "li") lines.push("- " + inlineText(li).trim());
        lines.push("");
        break;

      case "ol": {
        let i = 1;
        for (const li of child.children)
          if (li.tagName.toLowerCase() === "li") { lines.push(i++ + ". " + inlineText(li).trim()); }
        lines.push("");
        break;
      }

      case "table": {
        const rows = Array.from(child.querySelectorAll("tr"));
        rows.forEach((row, idx) => {
          const cells = Array.from(row.querySelectorAll("th, td"));
          lines.push("| " + cells.map(c => inlineText(c).trim() || " ").join(" | ") + " |");
          if (idx === 0) lines.push("| " + cells.map(() => "---").join(" | ") + " |");
        });
        lines.push("");
        break;
      }

      case "div": case "section": case "article": case "main":
      case "aside": case "header": case "footer": case "li":
        lines.push(...children());
        break;

      case "script": case "style": case "noscript": case "iframe": break;

      default: lines.push(...children()); break;
    }
  }
  return lines;
}

// ============================================================
// 10. TEXTE INLINE
// ============================================================
function inlineText(node) {
  let result = "";
  for (const child of node.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) { result += child.textContent.replace(/\s+/g, " "); continue; }
    if (child.nodeType !== Node.ELEMENT_NODE) continue;
    const tag = child.tagName.toLowerCase();
    switch (tag) {
      case "strong": case "b":   result += "**" + inlineText(child) + "**"; break;
      case "em":     case "i":   result += "_"  + inlineText(child) + "_";  break;
      case "code":               result += "`"  + child.textContent + "`";  break;
      case "s":      case "del": result += "~~" + inlineText(child) + "~~"; break;
      case "a": {
        const href = child.getAttribute("href");
        result += href ? "[" + inlineText(child) + "](" + href + ")" : inlineText(child);
        break;
      }
      case "br": result += " "; break;
      default:   result += inlineText(child); break;
    }
  }
  return result.trim();
}

// ============================================================
// 11. RÉSOLUTION URL RELATIVE → ABSOLUE
// ============================================================
function resolveUrl(href, baseUrl) {
  try { return new URL(href, baseUrl).href; }
  catch { return href; }
}
