Comment installer l'extension dans Firefox
1. Télécharge et dézippe le fichier firefox-extension.zip — tu obtiens un dossier avec manifest.json, popup.html et popup.js.
2. Ouvre Firefox et tape dans la barre d'adresse :
about:debugging
3. Clique sur Ce Firefox (dans le menu de gauche) → Charger un module complémentaire temporaire.
4. Navigue jusqu'au dossier dézippé et sélectionne le fichier manifest.json.
5. L'extension apparaît dans la barre d'outils Firefox avec son titre.


Comment l'utiliser ?
Une fois installée, c'est simple : tu vas sur n'importe quelle page web, tu cliques sur l'icône de 
l'extension dans la barre d'outils, et tu cliques sur "Convertir cette page". Le Markdown apparaît
 dans la zone de texte, et tu peux le copier en un clic.

Ce que fait le code
L'extension s'organise en 3 fichiers. manifest.json déclare l'extension à Firefox (permissions, fichiers, etc.). popup.html est l'interface visuelle du popup. popup.js contient toute la logique, découpée en étapes claires :

Il injecte un petit script dans la page active pour récupérer le HTML brut via executeScript
Il nettoie le HTML en supprimant les balises inutiles (scripts, navs, footers…)
Il tente de cibler le contenu principal (<main>, <article>, etc.)
Il parcourt le DOM récursivement et convertit chaque balise en son équivalent Markdown (titres, liens, tableaux, code, listes…)


Note : L'extension fonctionne en mode "temporaire" — elle disparaît au redémarrage de Firefox.