// ============================================================
// popup.js — Logique principale de l'extension "URL to Markdown"
// ============================================================

// --- Références aux éléments du DOM ---
const urlDisplay  = document.getElementById("url-display");
const btnConvert  = document.getElementById("btn-convert");
const statusEl    = document.getElementById("status");
const outputEl    = document.getElementById("output");
const btnCopy     = document.getElementById("btn-copy");
const btnDownload = document.getElementById("btn-download");

// --- État global : conserve les métadonnées pour le téléchargement ---
let currentMeta = { url: "", title: "", author: "", date: "" };

// ============================================================
// 1. AU CHARGEMENT DU POPUP : afficher l'URL de l'onglet actif
// ============================================================
browser.tabs.query({ active: true, currentWindow: true }).then(tabs => {
  const tab = tabs[0];
  if (tab && tab.url) {
    urlDisplay.textContent = tab.url;
  } else {
    urlDisplay.textContent = "Impossible de lire l'URL.";
  }
});

// ============================================================
// 2. CLIC SUR "CONVERTIR"
// ============================================================
btnConvert.addEventListener("click", async () => {
  btnConvert.disabled = true;
  setStatus("Extraction du contenu…", "");
  outputEl.value = "";
  btnCopy.disabled     = true;
  btnDownload.disabled = true;

  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tab  = tabs[0];

    // On injecte un script dans la page pour récupérer :
    //   - le HTML du body (pour le contenu)
    //   - le titre de la page
    //   - les métadonnées auteur (meta author, og:site_name, byline…)
    const results = await browser.tabs.executeScript(tab.id, {
      code: `
        // Tentative de récupération de l'auteur depuis plusieurs sources courantes
        function getAuthor() {
          // 1. Balise <meta name="author">
          const metaAuthor = document.querySelector('meta[name="author"]');
          if (metaAuthor && metaAuthor.content) return metaAuthor.content;

          // 2. Open Graph article:author
          const ogAuthor = document.querySelector('meta[property="article:author"]');
          if (ogAuthor && ogAuthor.content) return ogAuthor.content;

          // 3. JSON-LD (schéma structuré souvent présent sur les blogs)
          const jsonLd = document.querySelector('script[type="application/ld+json"]');
          if (jsonLd) {
            try {
              const data = JSON.parse(jsonLd.textContent);
              if (data.author) {
                if (typeof data.author === "string") return data.author;
                if (data.author.name) return data.author.name;
                if (Array.isArray(data.author) && data.author[0].name) return data.author[0].name;
              }
            } catch(e) {}
          }

          // 4. Sélecteurs HTML sémantiques courants
          const byline = document.querySelector(
            '[rel="author"], .author, .byline, [itemprop="author"], .post-author, .entry-author'
          );
          if (byline && byline.textContent.trim()) return byline.textContent.trim();

          return null; // auteur introuvable
        }

        // Retourner un objet avec toutes les infos nécessaires
        ({
          html:    document.body.innerHTML,
          title:   document.title || "",
          author:  getAuthor() || ""
        });
      `
    });

    const { html: rawHTML, title, author } = results[0];

    if (!rawHTML) {
      throw new Error("Impossible de récupérer le contenu de la page.");
    }

    // --- Construire la date de capture au format ISO (YYYY-MM-DD) ---
    const now  = new Date();
    const date = now.toISOString().split("T")[0]; // ex: "2025-06-12"

    // --- Stocker les métadonnées pour les réutiliser au téléchargement ---
    currentMeta = { url: tab.url, title, author, date };

    // --- Construire l'entête Markdown ---
    // Format "front matter" compatible avec Obsidian, Jekyll, Hugo, etc.
    const header = buildHeader(currentMeta);

    // --- Convertir le corps de la page en Markdown ---
    setStatus("Conversion en Markdown…", "");
    const body = htmlToMarkdown(rawHTML, tab.url);

    // --- Assembler entête + contenu ---
    const fullMarkdown = header + "\n" + body;

    outputEl.value       = fullMarkdown;
    btnCopy.disabled     = false;
    btnDownload.disabled = false;
    setStatus(`✓ Conversion terminée (${fullMarkdown.length} caractères)`, "success");

  } catch (err) {
    setStatus("Erreur : " + err.message, "error");
    console.error("[URL→MD]", err);
  } finally {
    btnConvert.disabled = false;
  }
});

// ============================================================
// 3. CLIC SUR "COPIER"
// ============================================================
btnCopy.addEventListener("click", () => {
  const text = outputEl.value;
  if (!text) return;

  outputEl.select();
  document.execCommand("copy");

  setStatus("✓ Copié dans le presse-papier !", "success");
  setTimeout(() => setStatus("", ""), 2000);
});

// ============================================================
// 4. CLIC SUR "TÉLÉCHARGER"
// Crée un fichier .md et déclenche son téléchargement via une
// URL objet (Blob), sans avoir besoin de la permission "downloads".
// ============================================================
btnDownload.addEventListener("click", () => {
  const text = outputEl.value;
  if (!text) return;

  // Transformer le contenu en Blob de type texte Markdown
  const blob = new Blob([text], { type: "text/markdown;charset=utf-8" });

  // Créer une URL temporaire pointant vers ce Blob
  const blobUrl = URL.createObjectURL(blob);

  // Générer un nom de fichier à partir du titre de la page
  // On nettoie les caractères interdits dans les noms de fichiers
  const safeName = (currentMeta.title || "page")
    .replace(/[^a-zA-Z0-9À-ÿ\s\-_]/g, "")  // supprimer caractères spéciaux
    .replace(/\s+/g, "-")                    // espaces → tirets
    .toLowerCase()
    .substring(0, 60);                        // limiter la longueur

  const filename = safeName + "-" + currentMeta.date + ".md";

  // Créer un lien invisible, cliquer dessus, puis nettoyer
  const a = document.createElement("a");
  a.href     = blobUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  // Libérer la mémoire allouée pour le Blob
  URL.revokeObjectURL(blobUrl);

  setStatus("✓ Téléchargement lancé : " + filename, "success");
  setTimeout(() => setStatus("", ""), 3000);
});

// ============================================================
// 5. CONSTRUCTION DE L'ENTÊTE MARKDOWN (front matter YAML)
//
// Génère un bloc --- ... --- en tête de fichier avec :
//   - title  : titre de la page
//   - url    : adresse source
//   - author : auteur détecté (ou "Inconnu")
//   - date   : date de capture
// ============================================================
function buildHeader(meta) {
  const author = meta.author || "Inconnu";
  const title  = meta.title  || meta.url;

  // Format YAML front matter, lisible par Obsidian, Jekyll, Hugo, Pandoc…
  return [
    "---",
    `title: "${title.replace(/"/g, "'")}"`,
    `url: "${meta.url}"`,
    `author: "${author}"`,
    `date: "${meta.date}"`,
    "---",
    ""
  ].join("\n");
}

// ============================================================
// 6. UTILITAIRE : changer le message de statut
// ============================================================
function setStatus(message, type) {
  statusEl.textContent = message;
  statusEl.className   = type || "";
}

// ============================================================
// 7. CONVERTISSEUR HTML → MARKDOWN
// ============================================================
function htmlToMarkdown(html, baseUrl) {
  const parser = new DOMParser();
  const doc    = parser.parseFromString(html, "text/html");

  // Supprimer les éléments non-lisibles
  const tagsToRemove = [
    "script", "style", "noscript", "iframe",
    "nav", "footer", "aside",
    "form", "button", "input", "select",
    "svg", "canvas", "video", "audio"
  ];
  tagsToRemove.forEach(tag => {
    doc.querySelectorAll(tag).forEach(el => el.remove());
  });

  // Cibler le contenu principal si possible
  const main = doc.querySelector("main, article, [role='main'], #content, .content, .post-content");
  const root = main || doc.body;

  const lines = nodeToMarkdown(root, { baseUrl, depth: 0 });

  return lines
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// ============================================================
// 8. CONVERSION RÉCURSIVE D'UN NŒUD DOM EN MARKDOWN
// ============================================================
function nodeToMarkdown(node, context) {
  const lines = [];

  for (const child of node.childNodes) {

    if (child.nodeType === Node.TEXT_NODE) {
      const text = child.textContent.replace(/\s+/g, " ").trim();
      if (text) lines.push(text);
      continue;
    }

    if (child.nodeType !== Node.ELEMENT_NODE) continue;

    const tag      = child.tagName.toLowerCase();
    const children = () => nodeToMarkdown(child, context);
    const inline   = () => inlineText(child);

    switch (tag) {
      case "h1": lines.push("\n# "      + inline() + "\n"); break;
      case "h2": lines.push("\n## "     + inline() + "\n"); break;
      case "h3": lines.push("\n### "    + inline() + "\n"); break;
      case "h4": lines.push("\n#### "   + inline() + "\n"); break;
      case "h5": lines.push("\n##### "  + inline() + "\n"); break;
      case "h6": lines.push("\n###### " + inline() + "\n"); break;

      case "p":  lines.push("\n" + inline() + "\n"); break;
      case "hr": lines.push("\n---\n");               break;
      case "br": lines.push("  ");                    break;

      case "a": {
        const href = child.getAttribute("href");
        const text = inline();
        if (!text) break;
        lines.push(href ? "[" + text + "](" + resolveUrl(href, context.baseUrl) + ")" : text);
        break;
      }

      case "img": {
        const src = child.getAttribute("src") || "";
        const alt = child.getAttribute("alt") || "image";
        if (src) lines.push("![" + alt + "](" + resolveUrl(src, context.baseUrl) + ")");
        break;
      }

      case "strong":
      case "b":   lines.push("**" + inline() + "**"); break;
      case "em":
      case "i":   lines.push("_"  + inline() + "_");  break;
      case "s":
      case "strike":
      case "del": lines.push("~~" + inline() + "~~"); break;

      case "code":
        if (child.parentElement && child.parentElement.tagName.toLowerCase() === "pre") {
          lines.push(...children());
        } else {
          lines.push("`" + child.textContent + "`");
        }
        break;

      case "pre": {
        const codeEl    = child.querySelector("code");
        const classStr  = (codeEl || child).className || "";
        const langMatch = classStr.match(/language-(\w+)/);
        const lang      = langMatch ? langMatch[1] : "";
        const codeText  = (codeEl || child).textContent;
        lines.push("\n```" + lang + "\n" + codeText.trim() + "\n```\n");
        break;
      }

      case "blockquote": {
        const inner = children().join("\n");
        lines.push("\n" + inner.trim().split("\n").map(l => "> " + l).join("\n") + "\n");
        break;
      }

      case "ul": {
        for (const li of child.children) {
          if (li.tagName.toLowerCase() === "li") lines.push("- " + inlineText(li).trim());
        }
        lines.push("");
        break;
      }

      case "ol": {
        let i = 1;
        for (const li of child.children) {
          if (li.tagName.toLowerCase() === "li") { lines.push(i + ". " + inlineText(li).trim()); i++; }
        }
        lines.push("");
        break;
      }

      case "table": {
        const rows = Array.from(child.querySelectorAll("tr"));
        if (rows.length === 0) break;
        rows.forEach((row, idx) => {
          const cells = Array.from(row.querySelectorAll("th, td"));
          lines.push("| " + cells.map(c => inlineText(c).trim() || " ").join(" | ") + " |");
          if (idx === 0) lines.push("| " + cells.map(() => "---").join(" | ") + " |");
        });
        lines.push("");
        break;
      }

      case "div": case "section": case "article": case "main":
      case "aside": case "header": case "footer": case "li":
        lines.push(...children());
        break;

      case "script": case "style": case "noscript": case "iframe":
        break;

      default:
        lines.push(...children());
        break;
    }
  }

  return lines;
}

// ============================================================
// 9. TEXTE INLINE
// ============================================================
function inlineText(node) {
  let result = "";

  for (const child of node.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) {
      result += child.textContent.replace(/\s+/g, " ");
      continue;
    }
    if (child.nodeType !== Node.ELEMENT_NODE) continue;

    const tag = child.tagName.toLowerCase();
    switch (tag) {
      case "strong":
      case "b":    result += "**" + inlineText(child) + "**"; break;
      case "em":
      case "i":    result += "_"  + inlineText(child) + "_";  break;
      case "code": result += "`"  + child.textContent + "`";  break;
      case "s":
      case "del":  result += "~~" + inlineText(child) + "~~"; break;
      case "a": {
        const href = child.getAttribute("href");
        const text = inlineText(child);
        result += href ? "[" + text + "](" + href + ")" : text;
        break;
      }
      case "br":   result += " ";               break;
      default:     result += inlineText(child); break;
    }
  }

  return result.trim();
}

// ============================================================
// 10. RÉSOLUTION D'URL RELATIVE → ABSOLUE
// ============================================================
function resolveUrl(href, baseUrl) {
  try { return new URL(href, baseUrl).href; }
  catch { return href; }
}
